<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Magyarországi adatok</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/covid.css')); ?>">
    <script src="../js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
    <div class="jumbotron bg-fej text-center">
        <h1>COVID</h1>
        <h3>Külkereskedelmi folyamatok 2020. január–május</h3>
    </div>
    <div class="row">
        <div class="col-md-12  bg-torzs">
            <h3>Magyar külkereskedelmi teljesítmény</h3>
            <h6>A Covid–19-járvány negatív gazdasági hatásai</h6>
            <p>„…A magyar külkereskedelmi teljesítményt vizsgálva azt láthatjuk, hogy a járvány világméretű terjedése a hazai külkereskedelmet is rendkívüli mértékben visszavetette. A járvány világméretű terjedésének kezdetén (2020. február) még kiugró exportszintet és jelentős többletet eredményezett, azonban ezt követően a külkereskedelmi forgalom jelentős mértékben kezdett csökkeni. 2020. január–áprilisban a teljes magyar külkereskedelmi forgalom 6 milliárd euróval mérséklődött az előző év azonos időszakához mérten. A termékexport 3,4 milliárd euróval, a termékimport 2,6 milliárd euróval csökkent, a külkereskedelmi egyenleg pedig 738 millió euróval romlott az egy évvel korábbihoz viszonyítva.”</p>
            <p><img src="<?php echo e(asset('assets/images/magyar_egyenleg.png')); ?>" class="img-thumbnail" alt="grafikon" title="grafikon"/></p>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-6 offset-3" >
            <h3>Magyarországi adatok részletes megtekintése:</h3>
        </div>
        <div class="col-sm-12 align-content-center" >
            <table class="col-sm-7 offset-3  table table-striped">
                <thead>
                <tr>
                    <th scope="col">Dátum</th>
                    <th scope="col">Import(millió euró)</th>
                    <th scope="col">Export(millió euró)</th>
                    <th scope="col">Egyenleg(millió euró)</th>
                </tr>
                </thead>
                <tbody>

                </tbody>
            </table>
        </div>
    </div>
</div>
</body>
</html>

<?php /**PATH C:\XAMPP\htdocs\covidLaravel\covid\resources\views/adatok.blade.php ENDPATH**/ ?>