<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>A európai régió  adatai</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/covid.css')); ?>">
    <script src="../js/bootstrap.min.js"></script>
</head>
<body>
<div class="container">
    <div class="jumbotron bg-fej text-center">
        <h1>COVID</h1>
        <h3>Külkereskedelmi folyamatok 2020. január–május</h3>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-sm-12 align-content-center bg-torzs">
            <h3>Az ön általválasztott régióba található régiók adatai.</h3>
            <h3>Európai</h3>
            <p>Az európai országok exportteljesítményét tekintve az elmúlt hónapok során a termék-külkereskedelem általános visszaesését láthattuk. A járvány terjedésének hatására különböző korlátozó intézkedések léptek hatályba, és közben a keresleti feltételek is jelentős mértékben romlottak, így a járvány negatív gazdasági hatásai – a jelenleg rendelkezésre álló nemzetközi adatok alapján – a márciusi és az áprilisi külkereskedelmi adatokban érhetők tetten. Az európai országok közül a legjelentősebb mértékben a dél-európaiak termékexportja esett vissza. A márciusi, éves alapon mért 13,6%-os mérséklődést áprilisban 40,7%-os visszaesés követte. A visegrádi országok termékexportja is érdemi csökkenést mutatott, áprilisban 35%-kal esett vissza.</p>
            <p><img src="<?php echo e(asset('assets/images/europa.png')); ?>" class="img-thumbnail" alt="grafikon" title="grafikon"/></p>
        </div>

    </div>

    <div class="col-sm-12 align-content-center" >
        <table class="col-sm-6 offset-3  table table-striped">
            <thead>
            <tr>
                <th scope="col">Régió neve</th>
                <th scope="col">Dátum</th>
                <th scope="col">Százalékpont</th>
            </tr>
            </thead>
            <tbody>


            </tbody>
        </table>

    </div>
</div>

</body>
</html>

<?php /**PATH C:\XAMPP\htdocs\covidLaravel\covid\resources\views/europa.blade.php ENDPATH**/ ?>