<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Világkereskedelmi régiók adatai</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/covid.css')); ?>">
    <script src="../js/bootstrap.min.js"></script>

</head>
<body>

<div class="container">
    <div class="jumbotron bg-fej text-center">
        <h1>COVID</h1>
        <h3>Külkereskedelmi folyamatok 2020. január–május</h3>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-sm-12 align-content-center bg-torzs">
            <h3>Az ön általválasztott régióba található régiók adatai.</h3>
        </div>
        <h3>Világkereskedelem</h3>
        <p><a href="https://www.ksh.hu/docs/hun/xftp/idoszaki/kulker/kul_foly_2020_05/index.html#avilgkereskedelemjelentsmrtkbenvisszaesett" target="_blank">A világkereskedelem jelentős mértékben visszaeset</a>
        <p>A világkereskedelem jelentős mértékben visszaesett
            „…2020 I. negyedévében a globális gazdasági folyamatok középpontjában a koronavírus okozta járvánnyal kapcsolatos intézkedések álltak. A járvány kiindulópontjának számító Kínában megtört a több évtizede tartó konjunktúra, és 2020 I. negyedévében 6,8%-kal csökkent a gazdaság teljesítménye. A világgazdaság legjelentősebb szereplőjének számító Egyesült Államokban 0,3%-ra lassult a növekedés üteme. A szűkebb környezetünket jelentő Európai Unióban (EU27) 2,6 %-kal csökkent a gazdaság teljesítménye.”</p>
        <p><img src="<?php echo e(asset('assets/images/vilag.png')); ?>" class="img-thumbnail" alt="grafikon" title="grafikon"/></p>
        <p><a href="https://www.cpb.nl/en/worldtrademonitor" target="_blank">Forrás: CPB Netherlands Bureau for Economic Policy Analysis, World Trade Monitor. </a></p>
    </div>

    <div class="col-sm-12 align-content-center" >
        <table class="col-sm-7 offset-3  table table-striped">
            <thead>
            <tr>
                <th scope="col">Régió neve</th>
                <th scope="col">Dátum</th>
                <th scope="col">Százalékpont</th>

            </tr>
            <?php $__currentLoopData = $vilagdatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vilagdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <th><?php echo e($vilagdata->zonanev); ?></th>
                <th><?php echo e($vilagdata->datum); ?></th>
                <th><?php echo e($vilagdata->szazalekpont); ?></th>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </thead>
            <tbody>

            </tbody>
        </table>

    </div>
</div>


</body>
</html>

<?php /**PATH C:\XAMPP\htdocs\covidLaravel\covid\resources\views/vilaggazdasag.blade.php ENDPATH**/ ?>