<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class oldalak extends Controller
{
    public function index(){
        $datas = DB::select('SELECT * FROM `vilagkereskedelem_zonak`');
        $eudatas = DB::select('SELECT * FROM `eu_zonak`');
        return view('index', ['zonak' => $datas, 'euzonak' => $eudatas]);
    }

    public function europa(){
        return view('europa');
    }

    public function adatok() {
        return view('adatok');
    }

    public function vilaggazdasag() {
        $vilagdatas = DB::select('SELECT * FROM `vilagkereskedelem_adatok` INNER JOIN vilagkereskedelem_zonak ON vilagkereskedelem_adatok.zonaID = vilagkereskedelem_zonak.id');
        return view('vilaggazdasag', ['vilagdatas' => $vilagdatas]);
    }
}
