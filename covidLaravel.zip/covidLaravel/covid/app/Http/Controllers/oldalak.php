<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class oldalak extends Controller
{
    public function europa(){
        return view('europa');
    }

    public function adatok() {
        return view('adatok');
    }

    public function vilaggazdasag() {
        return view('vilaggazdasag');
    }
}
