<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



Route::get('/',[ \App\Http\Controllers\oldalak::class, 'index'])->name('index');
Route::get('/europa',[\App\Http\Controllers\oldalak::class,'europa'])-> name('europa');
Route::get('/adatok',[\App\Http\Controllers\oldalak::class, 'adatok'])->name('adatok');
Route::get('/vilaggazdasag', [\App\Http\Controllers\oldalak::class,'vilaggazdasag'])->name('vilaggazdasag');
